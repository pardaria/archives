const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
    type: { type: String, required: true }, // 'message' ou 'file'
    channel: { type: String, required: true },
    username: { type: String, required: true },
    content: { type: String, required: true },
    fileType: { type: String }, // Tipo de arquivo (image, video, audio)
    isPreFormatted: { type: Boolean, default: false } // Novo campo
});

module.exports = mongoose.model('Message', messageSchema);