const socket = new WebSocket('ws://localhost:3000');
const chatMessages = document.getElementById('chat-messages');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');
const fileInput = document.getElementById('file-input');
const onlineUsers = document.getElementById('online-users');
const changeNickButton = document.getElementById('change-nick');
const channels = document.querySelectorAll('.channel');
const togglePreButton = document.getElementById('toggle-pre');
const sendFileButton = document.getElementById('send-file-button');

let username = generateKanjiName();
let isPreFormatted = false;
let currentChannel = 'geral'; // Canal padrão

// Gera um nome aleatório em kanji
function generateKanjiName() {
    const kanji = ['山', '川', '木', '花', '月', '日', '火', '水', '金', '土'];
    const kanjo = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];
    const hiragana = ['あ', 'い', 'う', 'え', 'お', 'か', 'き', 'く', 'け', 'こ'];
    const katakana = ['ア', 'イ', 'ウ', 'エ', 'オ', 'カ', 'キ', 'ク', 'ケ', 'コ'];
    const allCharacters = kanji.concat(hiragana, kanjo, katakana);
    let nick = '';
    for (let i = 0; i < 5; i++) {
        nick += allCharacters[Math.floor(Math.random() * allCharacters.length)];
    }
    return nick;
}

// Sanitiza entradas para prevenir XSS
function sanitizeInput(input) {
    return input.replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Função para formatar a data e hora no fuso horário de São Paulo
function getDateTimeSaoPaulo() {
    const options = {
        timeZone: 'America/Sao_Paulo',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false // Formato 24 horas
    };
    return new Date().toLocaleString('pt-BR', options);
}

// Exibe mensagens no chat
function displayMessage(message, isFile = false) {
    const messageElement = document.createElement('div');
    messageElement.className = 'message';

    if (!message.timestamp) {
        message.timestamp = getDateTimeSaoPaulo();
    }

    if (isFile) {
        if (message.fileType.startsWith('image')) {
            messageElement.innerHTML = `<img src="${message.content}" alt="Image">`;
        } else if (message.fileType.startsWith('video')) {
            messageElement.innerHTML = `<video src="${message.content}" controls></video>`;
        } else if (message.fileType.startsWith('audio')) {
            messageElement.innerHTML = `<audio src="${message.content}" controls></audio>`;
        }
    } else {
        messageElement.innerHTML = `<span style="color: ${message.color || '#8B0000'};"><span class="timestamp">[${message.timestamp}]</span>
        <span style="color: ${message.color || 'red'};">${message.username}: ${message.content}</span>`;
    }
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Alterna entre os canais
channels.forEach(channel => {
    channel.addEventListener('click', () => {
        channels.forEach(c => c.classList.remove('active'));
        channel.classList.add('active');
        currentChannel = channel.getAttribute('data-channel');
        document.getElementById('chat-header').textContent = currentChannel;
        chatMessages.innerHTML = '';
        socket.send(JSON.stringify({ type: 'getHistory', channel: currentChannel }));
    });
});

// Envia mensagens via WebSocket
sendButton.addEventListener('click', () => {
    const message = messageInput.value.trim();
    if (message) {
        socket.send(JSON.stringify({
            type: 'message',
            channel: currentChannel,
            username: username,
            content: message,
            isPreFormatted: isPreFormatted,
            timestamp: getDateTimeSaoPaulo()
        }));
        messageInput.value = '';
    }
});

// Envia mensagem ao pressionar Enter
messageInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        event.preventDefault();
        sendButton.click();
    }
});

// Envia arquivos via WebSocket
fileInput.addEventListener('change', () => {
    const file = fileInput.files[0];
    if (file && file.size <= 20 * 1024 * 1024) {
        const reader = new FileReader();
        reader.onload = (e) => {
            socket.send(JSON.stringify({
                type: 'file',
                channel: currentChannel,
                username: username,
                content: e.target.result,
                fileType: file.type
            }));
        };
        reader.readAsDataURL(file);
    } else {
        alert('Arquivo muito grande ou tipo não suportado.');
    }
});

// Altera o nick do usuário
changeNickButton.addEventListener('click', () => {
    const newNick = prompt('Digite seu novo nick:');
    if (newNick) {
        username = sanitizeInput(newNick);
        socket.send(JSON.stringify({
            type: 'setUsername',
            username: username
        }));
    }
});

// Recebe mensagens do servidor via WebSocket
socket.addEventListener('message', (event) => {
    const data = JSON.parse(event.data);

    if (data.type === 'message' || data.type === 'file') {
        // Verifica se a mensagem é um comando /clear
        if (data.content.startsWith('/clear')) {
            return; // Ignora a exibição do comando /clear
        }

        // Exibe a mensagem apenas se for do canal atual
        if (data.channel === currentChannel) {
            displayMessage(data, data.type === 'file');
        }
    } else if (data.type === 'users') {
        // Atualiza a lista de usuários online
        onlineUsers.innerHTML = data.users.map(user => `<div>${user}</div>`).join('');
    } else if (data.type === 'history') {
        // Exibe o histórico de mensagens do canal atual
        data.messages.forEach(message => displayMessage(message, message.type === 'file'));
    } else if (data.type === 'clearMessages') {
        // Remove as últimas N mensagens do chat
        if (data.channel === currentChannel) {
            const messages = chatMessages.querySelectorAll('.message');
            const numMessagesToRemove = Math.min(data.numMessages, messages.length);
            for (let i = 0; i < numMessagesToRemove; i++) {
                chatMessages.removeChild(messages[messages.length - 1 - i]);
            }
        }
    }
});

// Logs de depuração
socket.addEventListener('open', () => {
    console.log('Conectado ao WebSocket');
    socket.send(JSON.stringify({
        type: 'setUsername',
        username: username
    }));
});

socket.addEventListener('error', (error) => {
    console.error('Erro no WebSocket:', error);
});

socket.addEventListener('close', () => {
    console.log('Conexão WebSocket fechada');
});