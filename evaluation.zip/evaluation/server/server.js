const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const mongoose = require('mongoose');
const Message = require('./models/Message');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });



// Servir arquivos estáticos da pasta "public"
app.use(express.static('public'));

// Conecta ao MongoDB
mongoose.connect('mongodb://localhost:27017/chat')
    .then(() => {
        console.log('Conectado ao MongoDB');
    })
    .catch((err) => {
        console.error('Erro ao conectar ao MongoDB:', err);
    });

// Rastreia usuários online
const onlineUsers = new Map(); // Usamos um Map para associar conexões a nicks

wss.on('connection', (ws) => {
    console.log('Novo cliente conectado');

    // Define um nick padrão para o usuário
    ws.username = 'Anônimo'; // Inicialmente, o usuário é "Anônimo"
    onlineUsers.set(ws, ws.username); // Adiciona o usuário ao Map
    updateOnlineUsers(); // Atualiza a lista de usuários online

    // Recebe mensagens do cliente
    ws.on('message', (message) => {
        const data = JSON.parse(message);

        if (data.type === 'setUsername') {
            // Atualiza o nick do usuário
            ws.username = sanitizeInput(data.username);
            onlineUsers.set(ws, ws.username); // Atualiza o Map
            updateOnlineUsers(); // Atualiza a lista de usuários online
        } else if (data.type === 'message' || data.type === 'file') {
            // Verifica se a mensagem é um comando /clear
            if (data.content.startsWith('/clear')) {
                const parts = data.content.split(' ');
                if (parts.length === 2 && !isNaN(parts[1])) {
                    const numMessagesToDelete = parseInt(parts[1], 10);
                    deleteLastMessages(data.channel, numMessagesToDelete);
                }
                return; // Impede que o comando /clear seja salvo ou exibido
            }

            // Salva a mensagem no banco de dados
            const newMessage = new Message({
                type: data.type,
                channel: data.channel,
                username: ws.username,
                content: data.content,
                fileType: data.fileType,
                isPreFormatted: data.isPreFormatted
            });
            newMessage.save();

            // Envia a mensagem para todos os clientes no mesmo canal
            wss.clients.forEach(client => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(JSON.stringify({
                        type: data.type,
                        channel: data.channel,
                        username: ws.username,
                        content: data.content,
                        fileType: data.fileType,
                        isPreFormatted: data.isPreFormatted
                    }));
                }
            });
        } else if (data.type === 'getHistory') {
            // Envia o histórico de mensagens do canal solicitado
            Message.find({ channel: data.channel }).then(messages => {
                ws.send(JSON.stringify({ type: 'history', messages }));
            });
        }
    });

    // Remove o usuário da lista ao desconectar
    ws.on('close', () => {
        onlineUsers.delete(ws); // Remove o usuário do Map
        updateOnlineUsers(); // Atualiza a lista de usuários online
    });
});

// Função para deletar as últimas N mensagens de um canal
async function deleteLastMessages(channel, numMessagesToDelete) {
    try {
        const messages = await Message.find({ channel }).sort({ _id: -1 }).limit(numMessagesToDelete);
        const messageIds = messages.map(msg => msg._id);
        await Message.deleteMany({ _id: { $in: messageIds } });

        // Notifica todos os clientes para remover as mensagens
        wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                    type: 'clearMessages',
                    channel: channel,
                    numMessages: numMessagesToDelete
                }));
            }
        });
    } catch (err) {
        console.error('Erro ao deletar mensagens:', err);
    }
}

// Atualiza a lista de usuários online
function updateOnlineUsers() {
    const users = Array.from(onlineUsers.values()); // Obtém os nicks dos usuários
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ type: 'users', users }));
        }
    });
}

// Sanitiza entradas para prevenir XSS
function sanitizeInput(input) {
    return input.replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

// Rota padrão para servir o index.html
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// Inicia o servidor
server.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});